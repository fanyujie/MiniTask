﻿namespace ET
{

    public struct FiberInit
    {
        public Fiber Fiber { get; set; }
    }
}